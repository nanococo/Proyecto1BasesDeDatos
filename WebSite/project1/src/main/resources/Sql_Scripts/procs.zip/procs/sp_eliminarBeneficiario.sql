USE [Banco]
GO
/****** Object:  StoredProcedure [dbo].[sp_eliminarBeneficiario]    Script Date: 14/11/2020 7:25:16 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Brayan Marín>
-- Create date: <10/11/2020>
-- Description:	<SP que elimina al beneficiario>
-- =============================================
ALTER PROCEDURE [dbo].[sp_eliminarBeneficiario]

    @IdBeneficiario int,
    @IdCuentaAsociada int

AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    --Cambiar estado y asignar fecha de desactivacion
    DECLARE @Existingdate date
    SET @Existingdate=GETDATE()

    UPDATE [dbo].[Beneficiarios]
    SET
        EstaActivo = 0,
        FechaDesactivacion = CONVERT(varchar, @Existingdate,21)

    WHERE Id = @IdBeneficiario AND CuentaAsociadaId = @IdCuentaAsociada

END
