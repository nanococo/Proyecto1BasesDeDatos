USE [Banco]
GO

/****** Object:  StoredProcedure [dbo].[sp_insertarPersona]    Script Date: 14/11/2020 16:49:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Brayan Mar�n>
-- Create date: <14/11/2020>
-- Description:	<SP que inserta una persona.>
-- =============================================
CREATE PROCEDURE [dbo].[sp_insertarPersona] 
	-- Add the parameters for the stored procedure here
	@ValorDocumentoIdentidad VARCHAR (20),
	@TipoDocIdentidad INT,
	@Nombre VARCHAR(40),
	@FechaNacimiento DATE,
	@Email VARCHAR(50),
	@Telefono1 INT,
	@Telefono2 INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Insercion en tabla Persona
	INSERT INTO [dbo].[Persona] ([ValorDocumentoIdentidadDelCliente], [TipoDocIdentidadId], [Nombre], [FechaNacimiento], [Email], [Telefono1], [Telefono2])
	VALUES (@ValorDocumentoIdentidad, @TipoDocIdentidad, @Nombre, @FechaNacimiento, @Email, @Telefono1, @Telefono2)

END
GO


