USE [Banco]
GO
/****** Object:  StoredProcedure [dbo].[sp_testLogin]    Script Date: 14/11/2020 7:28:08 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER procedure [dbo].[sp_testLogin] @username varchar(30), @password varchar(30)
as
select * from Usuarios where Username = @username and Password = @password