USE [Banco]
        GO
        /****** Object:  StoredProcedure [dbo].[sp_editarBeneficiario]    Script Date: 14/11/2020 7:21:46 pm ******/
        SET ANSI_NULLS ON
        GO
        SET QUOTED_IDENTIFIER ON
        GO


        -- =============================================
        -- Author:		<Brayan Marín>
    -- Create date: <10/11/2020>
    -- Description:	<SP que edita los campos del beneficiario>
    -- =============================================
    ALTER PROCEDURE [dbo].[sp_editarBeneficiario]

    @IdPersona INT,
    @CuentaId INT,
    @NuevoNombre VARCHAR(40),
    @ParentescoNombre VARCHAR(40),
    @NuevoPorcentajeBeneficio INT,
    @NuevaFechaNacimiento date,
    @NuevoDocumentoIdentificacion VARCHAR(20),
    @NuevoEmail VARCHAR(50),
    @NuevoTelefono1 INT,
    @NuevoTelefono2 INT

    AS
    BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    DECLARE @PorcentajeTotalCuenta int

    --Se obtiene el porcentaje actual de la cuenta repartido entre los beneficiarios
    SET @PorcentajeTotalCuenta = (SELECT SUM(B.Porcentaje) FROM [dbo].[Beneficiarios] AS B WHERE B.CuentaAsociadaId = @CuentaId AND B.EstaActivo = 1 AND B.PersonaId <> @IdPersona)

    --Se valida que PorcentajeTotalCuenta no sea nulo
    IF (@PorcentajeTotalCuenta IS NULL)
    BEGIN
    SET @PorcentajeTotalCuenta = 0
    END

    --Si el porcentaje de beneficio es mayor que 100
    IF (@PorcentajeTotalCuenta + @NuevoPorcentajeBeneficio <= 100)
    BEGIN

    --Cambiar nombre
    UPDATE Persona
    SET Nombre = @NuevoNombre WHERE Id = @IdPersona

    --Cambiar parentesco
    UPDATE Beneficiarios
    SET ParentescoId = (SELECT Id FROM [dbo].[Parentescos] as PA WHERE @ParentescoNombre = PA.Nombre) WHERE PersonaId = @IdPersona

    --Cambiar porcentaje de beneficio
    UPDATE Beneficiarios
    SET Porcentaje = @NuevoPorcentajeBeneficio WHERE PersonaId = @IdPersona

    --Cambiar fechaNacimiento
    UPDATE Persona
    SET FechaNacimiento = @NuevaFechaNacimiento WHERE Id = @IdPersona

    --Cambiar DocIdentificación
    UPDATE Persona
    SET ValorDocumentoIdentidadDelCliente = @NuevoDocumentoIdentificacion WHERE Id = @IdPersona

    --Cambiar email
    UPDATE Persona
    SET Email = @NuevoEmail WHERE Id = @IdPersona

    --Cambiar telefono 1
    UPDATE Persona
    SET Telefono1 = @NuevoTelefono1 WHERE Id = @IdPersona

    --Cambiar telefono 2
    UPDATE Persona
    SET Telefono2 = @NuevoTelefono2 WHERE Id = @IdPersona

    END

    END
