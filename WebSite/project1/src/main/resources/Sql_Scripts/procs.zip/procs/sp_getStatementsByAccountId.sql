USE [Banco]
GO
/****** Object:  StoredProcedure [dbo].[sp_getStatementsByAccountId]    Script Date: 14/11/2020 7:27:04 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[sp_getStatementsByAccountId]
@accountId VARCHAR(20)
AS
SELECT *
FROM   EstadoCuenta
WHERE  CuentaAhorrosId = @accountId