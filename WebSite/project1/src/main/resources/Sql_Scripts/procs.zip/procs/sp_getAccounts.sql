USE [Banco]
GO
/****** Object:  StoredProcedure [dbo].[sp_getAccounts]    Script Date: 14/11/2020 7:25:52 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER procedure [dbo].[sp_getAccounts]  @username varchar(30)
as
select * from CuentaAhorros where Id in (select CuentaId from UsuariosVer where UserId = (select Usuarios.Id from Usuarios where Usuarios.Username = @username))