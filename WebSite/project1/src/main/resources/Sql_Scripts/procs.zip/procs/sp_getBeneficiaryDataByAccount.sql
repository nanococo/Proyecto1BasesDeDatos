USE [Banco]
GO
/****** Object:  StoredProcedure [dbo].[sp_getBeneficiaryDataByAccount]    Script Date: 14/11/2020 7:26:19 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER procedure [dbo].[sp_getBeneficiaryDataByAccount] @accountId varchar(30)
as
SELECT *
FROM   Persona,
       Beneficiarios
WHERE  Persona.Id IN (SELECT Personaid
                      FROM   Beneficiarios
                      WHERE  Beneficiarios.Cuentaasociadaid = @accountId)
  AND Beneficiarios.Cuentaasociadaid = @accountId
  AND Persona.Id = Beneficiarios.Personaid
  AND Beneficiarios.EstaActivo = '1'